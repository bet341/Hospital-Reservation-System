import { useMemo, useState } from "react";
import { HeartPulse } from "lucide-react";
import { COLORS, DOCTORS_SEED, APPTS_SEED } from "./data/seed.js";
import { next7Days } from "./lib/helpers.js";
import PatientView from "./components/PatientView.jsx";
import StaffView from "./components/StaffView.jsx";

export default function App() {
  const [view, setView] = useState("patient");
  const [doctors, setDoctors] = useState(DOCTORS_SEED);
  const days7 = useMemo(() => next7Days(), []);
  const [appointments, setAppointments] = useState(
    APPTS_SEED.map((a, i) => ({ ...a, date: days7[i % days7.length].dateStr }))
  );

  return (
    <div className="hr-root" style={{ minHeight: "100vh", background: COLORS.bg }}>
      <div style={{ position: "sticky", top: 0, zIndex: 10, background: `${COLORS.bg}F2`, backdropFilter: "blur(6px)", borderBottom: `1px solid ${COLORS.line}` }}>
        <div style={{ maxWidth: 1080, margin: "0 auto", padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <HeartPulse size={20} color={COLORS.accent} />
            <span className="hr-display" style={{ fontWeight: 600, fontSize: 17, color: COLORS.ink }}>Halcyon General</span>
          </div>
          <div style={{ display: "flex", background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 999, padding: 3 }}>
            {["patient", "staff"].map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                style={{
                  padding: "7px 16px", borderRadius: 999, border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer",
                  background: view === v ? COLORS.primary : "transparent",
                  color: view === v ? "#fff" : COLORS.inkSoft,
                }}
              >
                {v === "patient" ? "Patient" : "Staff"}
              </button>
            ))}
          </div>
        </div>
      </div>

      {view === "patient" ? (
        <PatientView doctors={doctors} appointments={appointments} setAppointments={setAppointments} />
      ) : (
        <StaffView doctors={doctors} setDoctors={setDoctors} appointments={appointments} setAppointments={setAppointments} />
      )}
    </div>
  );
}
