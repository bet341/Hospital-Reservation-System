import { HeartPulse, Baby, Bone, Sparkles, Brain, Stethoscope } from "lucide-react";

/* ---------------------------------- design tokens ---------------------------------- */

export const COLORS = {
  bg: "#F2F5F3",
  surface: "#FFFFFF",
  ink: "#12231D",
  inkSoft: "#5B6B65",
  primary: "#1F6F5C",
  primaryDark: "#14493D",
  accent: "#E2543B",
  amber: "#C98A2C",
  slate: "#4A5B72",
  line: "#D9E2DE",
};

export const DEPARTMENTS = [
  { name: "Cardiology", icon: HeartPulse, color: COLORS.accent },
  { name: "Pediatrics", icon: Baby, color: COLORS.amber },
  { name: "Orthopedics", icon: Bone, color: COLORS.primaryDark },
  { name: "Dermatology", icon: Sparkles, color: COLORS.primary },
  { name: "Neurology", icon: Brain, color: COLORS.slate },
  { name: "General Medicine", icon: Stethoscope, color: COLORS.inkSoft },
];

export const deptMeta = (name) =>
  DEPARTMENTS.find((d) => d.name === name) || DEPARTMENTS[5];

/* ---------------------------------- seed data ---------------------------------- */

export const DOCTORS_SEED = [
  { id: "d1", name: "Dr. Amara Chen", dept: "Cardiology", exp: 14, bio: "Interventional cardiology, heart rhythm disorders." },
  { id: "d2", name: "Dr. Samuel Okafor", dept: "Cardiology", exp: 9, bio: "Preventive cardiology and echocardiography." },
  { id: "d3", name: "Dr. Lidya Petrov", dept: "Pediatrics", exp: 11, bio: "General pediatrics and childhood immunization." },
  { id: "d4", name: "Dr. Yonas Reyes", dept: "Orthopedics", exp: 16, bio: "Joint replacement and sports injuries." },
  { id: "d5", name: "Dr. Hanna Kim", dept: "Dermatology", exp: 7, bio: "Clinical and cosmetic dermatology." },
  { id: "d6", name: "Dr. Daniel Novak", dept: "Neurology", exp: 13, bio: "Headache disorders and epilepsy care." },
  { id: "d7", name: "Dr. Selam Rossi", dept: "General Medicine", exp: 5, bio: "Primary care and chronic disease management." },
  { id: "d8", name: "Dr. Robel Hughes", dept: "Orthopedics", exp: 10, bio: "Spine and trauma orthopedics." },
];

export const SLOTS = [
  "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
  "13:30", "14:00", "14:30", "15:00", "15:30", "16:00",
];

export const APPTS_SEED = [
  { id: "a1", code: "HGH-2231", patientName: "Marcus Webb", phone: "555-0142", doctorId: "d1", dept: "Cardiology", date: null, time: "10:00", status: "Confirmed" },
  { id: "a2", code: "HGH-4407", patientName: "Priya Anand", phone: "555-0198", doctorId: "d3", dept: "Pediatrics", date: null, time: "09:30", status: "Pending" },
  { id: "a3", code: "HGH-8850", patientName: "Elena Ruiz", phone: "555-0125", doctorId: "d6", dept: "Neurology", date: null, time: "14:00", status: "Pending" },
  { id: "a4", code: "HGH-1193", patientName: "Tom Ashworth", phone: "555-0170", doctorId: "d4", dept: "Orthopedics", date: null, time: "11:00", status: "Confirmed" },
];
