import { useMemo } from "react";
import { ArrowRight } from "lucide-react";
import { COLORS, deptMeta, SLOTS } from "../data/seed.js";
import { next7Days, getScheduleGaps } from "../lib/helpers.js";
import DeptBadge from "./DeptBadge.jsx";

export default function DoctorCard({ doctor, appointments, onSelect }) {
  const meta = deptMeta(doctor.dept);
  const Icon = meta.icon;
  const days = useMemo(() => next7Days(), []);
  const nextAvailable = useMemo(() => {
    for (const d of days) {
      const gaps = new Set(getScheduleGaps(doctor.id, d.dateStr));
      appointments
        .filter((a) => a.doctorId === doctor.id && a.date === d.dateStr && a.status !== "Cancelled")
        .forEach((a) => gaps.add(a.time));
      if (gaps.size < SLOTS.length) {
        return d.isToday ? "Today" : `${d.weekday} ${d.day} ${d.month}`;
      }
    }
    return "Next week";
  }, [doctor.id, appointments, days]);

  const initials = doctor.name.replace("Dr. ", "").split(" ").map((n) => n[0]).join("").slice(0, 2);

  return (
    <div
      style={{
        background: COLORS.surface,
        border: `1px solid ${COLORS.line}`,
        borderRadius: 16,
        padding: 20,
        display: "flex",
        flexDirection: "column",
        gap: 14,
      }}
    >
      <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
        <div
          className="hr-display"
          style={{
            width: 52, height: 52, borderRadius: "50%",
            background: `${meta.color}1A`, color: meta.color,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 18, fontWeight: 600, flexShrink: 0,
          }}
        >
          {initials}
        </div>
        <div style={{ minWidth: 0 }}>
          <div className="hr-display" style={{ fontSize: 17, fontWeight: 600, color: COLORS.ink, lineHeight: 1.2 }}>
            {doctor.name}
          </div>
          <DeptBadge dept={doctor.dept} />
        </div>
      </div>

      <p style={{ fontSize: 13.5, color: COLORS.inkSoft, margin: 0, lineHeight: 1.5 }}>{doctor.bio}</p>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 4 }}>
        <div style={{ fontSize: 12.5, color: COLORS.inkSoft }}>{doctor.exp} yrs experience</div>
        <div
          className="hr-mono"
          style={{ fontSize: 11.5, color: meta.color, display: "flex", alignItems: "center", gap: 4, fontWeight: 600 }}
        >
          <Icon size={12} /> {nextAvailable}
        </div>
      </div>

      <button
        onClick={() => onSelect(doctor.id)}
        style={{
          marginTop: 4, background: COLORS.primary, color: "#fff", border: "none",
          borderRadius: 10, padding: "10px 14px", fontSize: 14, fontWeight: 600,
          cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
        }}
      >
        Book appointment <ArrowRight size={15} />
      </button>
    </div>
  );
}
