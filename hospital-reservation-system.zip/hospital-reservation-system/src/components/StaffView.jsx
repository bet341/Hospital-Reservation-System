import { useState } from "react";
import { LayoutDashboard, ClipboardList, Building2 } from "lucide-react";
import { COLORS } from "../data/seed.js";
import StaffOverview from "./StaffOverview.jsx";
import StaffAppointments from "./StaffAppointments.jsx";
import StaffDoctors from "./StaffDoctors.jsx";

export default function StaffView({ doctors, setDoctors, appointments, setAppointments }) {
  const [tab, setTab] = useState("overview");
  const tabs = [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "appointments", label: "Reservations", icon: ClipboardList },
    { id: "doctors", label: "Doctors", icon: Building2 },
  ];

  return (
    <div style={{ maxWidth: 1080, margin: "0 auto", padding: "28px 20px 60px", display: "flex", gap: 24 }}>
      <div style={{ width: 190, flexShrink: 0 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          {tabs.map((t) => {
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                style={{
                  display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderRadius: 10,
                  border: "none", cursor: "pointer", textAlign: "left", fontSize: 13.5, fontWeight: 600,
                  background: active ? COLORS.primary : "transparent",
                  color: active ? "#fff" : COLORS.inkSoft,
                }}
              >
                <t.icon size={16} /> {t.label}
              </button>
            );
          })}
        </div>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        {tab === "overview" && <StaffOverview appointments={appointments} doctors={doctors} />}
        {tab === "appointments" && <StaffAppointments appointments={appointments} setAppointments={setAppointments} doctors={doctors} />}
        {tab === "doctors" && <StaffDoctors doctors={doctors} setDoctors={setDoctors} />}
      </div>
    </div>
  );
}
