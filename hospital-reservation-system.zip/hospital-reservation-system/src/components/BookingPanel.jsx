import { useMemo, useState } from "react";
import { Calendar, Clock, User, ArrowLeft } from "lucide-react";
import { COLORS, deptMeta, SLOTS } from "../data/seed.js";
import { next7Days, getScheduleGaps } from "../lib/helpers.js";
import DeptBadge from "./DeptBadge.jsx";

export default function BookingPanel({ doctor, appointments, onCancel, onConfirm }) {
  const days = useMemo(() => next7Days(), []);
  const [dateStr, setDateStr] = useState(days[0].dateStr);
  const [time, setTime] = useState(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const meta = deptMeta(doctor.dept);

  const takenSlots = useMemo(() => {
    const gaps = new Set(getScheduleGaps(doctor.id, dateStr));
    appointments
      .filter((a) => a.doctorId === doctor.id && a.date === dateStr && a.status !== "Cancelled")
      .forEach((a) => gaps.add(a.time));
    return gaps;
  }, [doctor.id, dateStr, appointments]);

  const canConfirm = time && name.trim() && phone.trim();

  return (
    <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 20, padding: 28 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
        <button
          onClick={onCancel}
          style={{ background: "none", border: "none", color: COLORS.inkSoft, cursor: "pointer", display: "flex", alignItems: "center", gap: 6, fontSize: 13.5, padding: 0 }}
        >
          <ArrowLeft size={15} /> Back to doctors
        </button>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
        <div
          className="hr-display"
          style={{ width: 44, height: 44, borderRadius: "50%", background: `${meta.color}1A`, color: meta.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, fontWeight: 600 }}
        >
          {doctor.name.replace("Dr. ", "").split(" ").map((n) => n[0]).join("")}
        </div>
        <div>
          <div className="hr-display" style={{ fontSize: 19, fontWeight: 600, color: COLORS.ink }}>{doctor.name}</div>
          <DeptBadge dept={doctor.dept} />
        </div>
      </div>

      <div style={{ marginBottom: 22 }}>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: COLORS.inkSoft, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 10 }}>
          <Calendar size={13} style={{ verticalAlign: -2, marginRight: 5 }} /> Choose a date
        </div>
        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 4 }}>
          {days.map((d) => (
            <button
              key={d.dateStr}
              onClick={() => { setDateStr(d.dateStr); setTime(null); }}
              style={{
                flexShrink: 0, minWidth: 64, padding: "10px 8px", borderRadius: 12,
                border: `1px solid ${dateStr === d.dateStr ? COLORS.primary : COLORS.line}`,
                background: dateStr === d.dateStr ? COLORS.primary : "transparent",
                color: dateStr === d.dateStr ? "#fff" : COLORS.ink,
                cursor: "pointer", textAlign: "center",
              }}
            >
              <div style={{ fontSize: 11, opacity: 0.85 }}>{d.isToday ? "Today" : d.weekday}</div>
              <div className="hr-display" style={{ fontSize: 17, fontWeight: 600 }}>{d.day}</div>
            </button>
          ))}
        </div>
      </div>

      <div style={{ marginBottom: 22 }}>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: COLORS.inkSoft, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 10 }}>
          <Clock size={13} style={{ verticalAlign: -2, marginRight: 5 }} /> Choose a time
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(84px, 1fr))", gap: 8 }}>
          {SLOTS.map((s) => {
            const taken = takenSlots.has(s);
            const active = time === s;
            return (
              <button
                key={s}
                disabled={taken}
                onClick={() => setTime(s)}
                className="hr-mono"
                style={{
                  padding: "9px 6px", borderRadius: 9, fontSize: 13,
                  border: `1px solid ${active ? COLORS.primary : COLORS.line}`,
                  background: active ? COLORS.primary : taken ? "#F3F1EC" : "transparent",
                  color: active ? "#fff" : taken ? "#B8BDB9" : COLORS.ink,
                  cursor: taken ? "not-allowed" : "pointer",
                  textDecoration: taken ? "line-through" : "none",
                }}
              >
                {s}
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ marginBottom: 22, display: "grid", gap: 12 }}>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: COLORS.inkSoft, textTransform: "uppercase", letterSpacing: 0.5 }}>
          <User size={13} style={{ verticalAlign: -2, marginRight: 5 }} /> Your details
        </div>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Full name"
          style={{ padding: "11px 14px", borderRadius: 10, border: `1px solid ${COLORS.line}`, fontSize: 14, outline: "none", fontFamily: "inherit" }}
        />
        <input
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          placeholder="Phone number"
          style={{ padding: "11px 14px", borderRadius: 10, border: `1px solid ${COLORS.line}`, fontSize: 14, outline: "none", fontFamily: "inherit" }}
        />
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Reason for visit (optional)"
          rows={2}
          style={{ padding: "11px 14px", borderRadius: 10, border: `1px solid ${COLORS.line}`, fontSize: 14, outline: "none", resize: "vertical", fontFamily: "inherit" }}
        />
      </div>

      <button
        disabled={!canConfirm}
        onClick={() =>
          onConfirm({
            doctorId: doctor.id,
            dept: doctor.dept,
            date: dateStr,
            time,
            patientName: name.trim(),
            phone: phone.trim(),
            notes: notes.trim(),
          })
        }
        style={{
          width: "100%", padding: "13px 14px", borderRadius: 12, border: "none",
          background: canConfirm ? COLORS.accent : "#E5DFD6",
          color: canConfirm ? "#fff" : "#A9A296",
          fontSize: 15, fontWeight: 700, cursor: canConfirm ? "pointer" : "not-allowed",
        }}
      >
        Reserve appointment
      </button>
    </div>
  );
}
