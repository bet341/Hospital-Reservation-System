import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { COLORS, DEPARTMENTS, deptMeta } from "../data/seed.js";
import DeptBadge from "./DeptBadge.jsx";

export default function StaffDoctors({ doctors, setDoctors }) {
  const [name, setName] = useState("");
  const [dept, setDept] = useState(DEPARTMENTS[0].name);
  const [exp, setExp] = useState("");
  const [bio, setBio] = useState("");

  const addDoctor = () => {
    if (!name.trim()) return;
    setDoctors((prev) => [
      ...prev,
      { id: "d" + Date.now(), name: name.trim().startsWith("Dr.") ? name.trim() : `Dr. ${name.trim()}`, dept, exp: Number(exp) || 0, bio: bio.trim() || "New team member." },
    ]);
    setName(""); setExp(""); setBio("");
  };
  const removeDoctor = (id) => setDoctors((prev) => prev.filter((d) => d.id !== id));

  return (
    <div>
      <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, padding: 20, marginBottom: 20 }}>
        <div className="hr-display" style={{ fontSize: 16, fontWeight: 600, marginBottom: 14, color: COLORS.ink }}>Add a doctor</div>
        <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 0.6fr", gap: 10, marginBottom: 10 }}>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" style={{ padding: "10px 12px", borderRadius: 10, border: `1px solid ${COLORS.line}`, fontSize: 13.5, outline: "none", fontFamily: "inherit" }} />
          <select value={dept} onChange={(e) => setDept(e.target.value)} style={{ padding: "10px 12px", borderRadius: 10, border: `1px solid ${COLORS.line}`, fontSize: 13.5, outline: "none", fontFamily: "inherit" }}>
            {DEPARTMENTS.map((d) => <option key={d.name} value={d.name}>{d.name}</option>)}
          </select>
          <input value={exp} onChange={(e) => setExp(e.target.value)} placeholder="Yrs exp." type="number" style={{ padding: "10px 12px", borderRadius: 10, border: `1px solid ${COLORS.line}`, fontSize: 13.5, outline: "none", fontFamily: "inherit" }} />
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <input value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Short bio (optional)" style={{ flex: 1, padding: "10px 12px", borderRadius: 10, border: `1px solid ${COLORS.line}`, fontSize: 13.5, outline: "none", fontFamily: "inherit" }} />
          <button onClick={addDoctor} style={{ background: COLORS.primary, color: "#fff", border: "none", borderRadius: 10, padding: "0 18px", fontWeight: 600, fontSize: 13.5, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}>
            <Plus size={15} /> Add
          </button>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 12 }}>
        {doctors.map((d) => {
          const meta = deptMeta(d.dept);
          return (
            <div key={d.id} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 16, display: "flex", flexDirection: "column", gap: 8 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div>
                  <div className="hr-display" style={{ fontWeight: 600, color: COLORS.ink, fontSize: 15 }}>{d.name}</div>
                  <DeptBadge dept={d.dept} size={12} />
                </div>
                <button onClick={() => removeDoctor(d.id)} style={{ background: "none", border: "none", cursor: "pointer", color: COLORS.accent }}>
                  <Trash2 size={15} />
                </button>
              </div>
              <div style={{ fontSize: 12.5, color: COLORS.inkSoft }}>{d.exp} yrs experience</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
