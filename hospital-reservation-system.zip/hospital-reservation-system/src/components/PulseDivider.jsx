import { COLORS } from "../data/seed.js";

export default function PulseDivider({ color = COLORS.primary, height = 32 }) {
  return (
    <svg viewBox="0 0 400 40" style={{ width: "100%", height }} preserveAspectRatio="none">
      <polyline
        points="0,20 60,20 80,20 90,5 100,35 110,20 130,20 160,20 180,20 190,8 200,32 210,20 240,20 400,20"
        fill="none"
        stroke={color}
        strokeWidth="2"
      />
    </svg>
  );
}
