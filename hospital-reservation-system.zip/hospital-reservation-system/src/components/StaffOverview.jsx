import { useMemo } from "react";
import { Calendar, AlertCircle, Activity, Users } from "lucide-react";
import { COLORS } from "../data/seed.js";
import { next7Days } from "../lib/helpers.js";
import DeptBadge from "./DeptBadge.jsx";
import StatusPill from "./StatusPill.jsx";

export default function StaffOverview({ appointments, doctors }) {
  const days = useMemo(() => next7Days(), []);
  const todayStr = days[0].dateStr;
  const todayCount = appointments.filter((a) => a.date === todayStr && a.status !== "Cancelled").length;
  const pendingCount = appointments.filter((a) => a.status === "Pending").length;
  const weekCount = appointments.filter((a) => days.some((d) => d.dateStr === a.date) && a.status !== "Cancelled").length;

  const upcoming = [...appointments]
    .filter((a) => a.status !== "Cancelled")
    .sort((a, b) => (a.date || "").localeCompare(b.date || "") || a.time.localeCompare(b.time))
    .slice(0, 5);

  const stats = [
    { label: "Today's reservations", value: todayCount, icon: Calendar, color: COLORS.primary },
    { label: "Pending approval", value: pendingCount, icon: AlertCircle, color: COLORS.amber },
    { label: "This week", value: weekCount, icon: Activity, color: COLORS.accent },
    { label: "Doctors on staff", value: doctors.length, icon: Users, color: COLORS.slate },
  ];

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 14, marginBottom: 28 }}>
        {stats.map((s) => (
          <div key={s.label} style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 14, padding: 18 }}>
            <s.icon size={18} color={s.color} />
            <div className="hr-display" style={{ fontSize: 28, fontWeight: 600, color: COLORS.ink, marginTop: 10 }}>{s.value}</div>
            <div style={{ fontSize: 12.5, color: COLORS.inkSoft, marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, padding: 22 }}>
        <div className="hr-display" style={{ fontSize: 17, fontWeight: 600, marginBottom: 14, color: COLORS.ink }}>Next up</div>
        {upcoming.length === 0 && <div style={{ color: COLORS.inkSoft, fontSize: 13.5 }}>No upcoming reservations.</div>}
        <div style={{ display: "grid", gap: 10 }}>
          {upcoming.map((a) => (
            <div key={a.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 0", borderTop: `1px solid ${COLORS.bg}` }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div className="hr-mono" style={{ fontSize: 13, color: COLORS.primaryDark, fontWeight: 700, width: 58 }}>{a.time}</div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: COLORS.ink }}>{a.patientName}</div>
                  <DeptBadge dept={a.dept} size={12} />
                </div>
              </div>
              <StatusPill status={a.status} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
