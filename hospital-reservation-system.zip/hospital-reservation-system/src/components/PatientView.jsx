import { useState } from "react";
import { COLORS, DEPARTMENTS, deptMeta } from "../data/seed.js";
import { generateCode } from "../lib/helpers.js";
import DoctorCard from "./DoctorCard.jsx";
import BookingPanel from "./BookingPanel.jsx";
import TicketStub from "./TicketStub.jsx";
import PulseDivider from "./PulseDivider.jsx";

export default function PatientView({ doctors, appointments, setAppointments }) {
  const [deptFilter, setDeptFilter] = useState("All");
  const [selectedDoctorId, setSelectedDoctorId] = useState(null);
  const [confirmedId, setConfirmedId] = useState(null);

  const filteredDoctors = deptFilter === "All" ? doctors : doctors.filter((d) => d.dept === deptFilter);
  const selectedDoctor = doctors.find((d) => d.id === selectedDoctorId);
  const confirmedAppt = appointments.find((a) => a.id === confirmedId);

  if (confirmedAppt) {
    const doc = doctors.find((d) => d.id === confirmedAppt.doctorId);
    return (
      <div style={{ padding: "48px 20px" }}>
        <TicketStub
          appt={confirmedAppt}
          doctor={doc}
          onBookAnother={() => { setConfirmedId(null); setSelectedDoctorId(null); }}
        />
      </div>
    );
  }

  if (selectedDoctor) {
    return (
      <div style={{ maxWidth: 640, margin: "0 auto", padding: "32px 20px" }}>
        <BookingPanel
          doctor={selectedDoctor}
          appointments={appointments}
          onCancel={() => setSelectedDoctorId(null)}
          onConfirm={(data) => {
            const newAppt = { id: "a" + Date.now(), code: generateCode(), status: "Pending", ...data };
            setAppointments((prev) => [...prev, newAppt]);
            setConfirmedId(newAppt.id);
          }}
        />
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 1080, margin: "0 auto", padding: "32px 20px 60px" }}>
      <div style={{ textAlign: "center", marginBottom: 28 }}>
        <div style={{ fontSize: 12.5, fontWeight: 700, color: COLORS.accent, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 10 }}>
          Halcyon General Hospital
        </div>
        <h1 className="hr-display" style={{ fontSize: 40, fontWeight: 600, color: COLORS.ink, margin: "0 0 12px" }}>
          Reserve your appointment
        </h1>
        <p style={{ color: COLORS.inkSoft, fontSize: 15.5, maxWidth: 480, margin: "0 auto" }}>
          Pick a department, choose a doctor, and hold a time slot in under a minute.
        </p>
        <div style={{ maxWidth: 300, margin: "18px auto 0" }}>
          <PulseDivider />
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", marginBottom: 28 }}>
        {["All", ...DEPARTMENTS.map((d) => d.name)].map((name) => {
          const active = deptFilter === name;
          const meta = name === "All" ? null : deptMeta(name);
          return (
            <button
              key={name}
              onClick={() => setDeptFilter(name)}
              style={{
                display: "flex", alignItems: "center", gap: 6, padding: "8px 14px", borderRadius: 999,
                border: `1px solid ${active ? COLORS.primary : COLORS.line}`,
                background: active ? COLORS.primary : "transparent",
                color: active ? "#fff" : COLORS.ink,
                fontSize: 13.5, fontWeight: 600, cursor: "pointer",
              }}
            >
              {meta && <meta.icon size={14} />}
              {name}
            </button>
          );
        })}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 16 }}>
        {filteredDoctors.map((doc) => (
          <DoctorCard key={doc.id} doctor={doc} appointments={appointments} onSelect={setSelectedDoctorId} />
        ))}
      </div>
    </div>
  );
}
