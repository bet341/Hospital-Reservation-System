import { COLORS } from "../data/seed.js";

export default function StatusPill({ status }) {
  const map = {
    Confirmed: { bg: "#E4F0EC", fg: COLORS.primaryDark },
    Pending: { bg: "#FBF0DE", fg: "#8A5F17" },
    Cancelled: { bg: "#F7E4E0", fg: "#A13A28" },
  };
  const s = map[status] || map.Pending;
  return (
    <span
      className="hr-mono"
      style={{
        background: s.bg,
        color: s.fg,
        fontSize: 12,
        fontWeight: 600,
        padding: "4px 10px",
        borderRadius: 999,
        letterSpacing: 0.3,
        whiteSpace: "nowrap",
      }}
    >
      {status}
    </span>
  );
}
