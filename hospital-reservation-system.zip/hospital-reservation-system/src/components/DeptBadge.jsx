import { deptMeta } from "../data/seed.js";

export default function DeptBadge({ dept, size = 14 }) {
  const meta = deptMeta(dept);
  const Icon = meta.icon;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: meta.color, fontWeight: 600, fontSize: 13 }}>
      <Icon size={size} /> {dept}
    </span>
  );
}
