import { useMemo } from "react";
import { COLORS } from "../data/seed.js";
import { next7Days } from "../lib/helpers.js";
import DeptBadge from "./DeptBadge.jsx";
import PulseDivider from "./PulseDivider.jsx";

export default function TicketStub({ appt, doctor, onBookAnother }) {
  const days = useMemo(() => next7Days(), []);
  const dayMeta = days.find((d) => d.dateStr === appt.date);
  const dateLabel = dayMeta ? `${dayMeta.weekday} ${dayMeta.day} ${dayMeta.month}` : appt.date;

  return (
    <div style={{ maxWidth: 560, margin: "0 auto" }}>
      <div style={{ display: "flex", boxShadow: "0 1px 2px rgba(18,35,29,0.06), 0 12px 28px rgba(18,35,29,0.10)", borderRadius: 18, overflow: "hidden" }}>
        <div style={{ flex: 1, background: COLORS.surface, padding: 28 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.accent, textTransform: "uppercase", letterSpacing: 1, marginBottom: 6 }}>
            Reservation {appt.status}
          </div>
          <div className="hr-display" style={{ fontSize: 22, fontWeight: 600, color: COLORS.ink, marginBottom: 4 }}>
            {appt.patientName}
          </div>
          <div style={{ fontSize: 13.5, color: COLORS.inkSoft, marginBottom: 18 }}>with {doctor.name}</div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            <div>
              <div style={{ fontSize: 11, color: COLORS.inkSoft, textTransform: "uppercase", letterSpacing: 0.5 }}>Department</div>
              <DeptBadge dept={appt.dept} />
            </div>
            <div>
              <div style={{ fontSize: 11, color: COLORS.inkSoft, textTransform: "uppercase", letterSpacing: 0.5 }}>Date</div>
              <div className="hr-display" style={{ fontWeight: 600, color: COLORS.ink }}>{dateLabel}</div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: COLORS.inkSoft, textTransform: "uppercase", letterSpacing: 0.5 }}>Time</div>
              <div className="hr-mono" style={{ fontWeight: 600, color: COLORS.ink }}>{appt.time}</div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: COLORS.inkSoft, textTransform: "uppercase", letterSpacing: 0.5 }}>Phone</div>
              <div style={{ fontWeight: 600, color: COLORS.ink, fontSize: 13.5 }}>{appt.phone}</div>
            </div>
          </div>
        </div>

        <div style={{ position: "relative", width: 170, background: COLORS.surface, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10, padding: "24px 16px" }}>
          <div
            style={{
              position: "absolute", left: 0, top: 0, bottom: 0, borderLeft: `2px dashed ${COLORS.line}`,
            }}
          />
          <div style={{ position: "absolute", left: -11, top: -11, width: 22, height: 22, borderRadius: "50%", background: COLORS.bg }} />
          <div style={{ position: "absolute", left: -11, bottom: -11, width: 22, height: 22, borderRadius: "50%", background: COLORS.bg }} />
          <div style={{ fontSize: 10.5, color: COLORS.inkSoft, textTransform: "uppercase", letterSpacing: 1 }}>Confirmation</div>
          <div className="hr-mono" style={{ fontSize: 19, fontWeight: 700, color: COLORS.primaryDark, letterSpacing: 1 }}>{appt.code}</div>
          <PulseDivider color={COLORS.accent} height={20} />
          <div style={{ fontSize: 10.5, color: COLORS.inkSoft, textAlign: "center" }}>Halcyon General Hospital</div>
        </div>
      </div>

      <p style={{ textAlign: "center", fontSize: 13, color: COLORS.inkSoft, marginTop: 16 }}>
        {appt.status === "Pending"
          ? "Your reservation is awaiting confirmation from our front desk. Keep your confirmation code handy."
          : "Your reservation is confirmed. Please arrive 15 minutes early."}
      </p>

      <div style={{ textAlign: "center", marginTop: 18 }}>
        <button
          onClick={onBookAnother}
          style={{ background: "transparent", border: `1px solid ${COLORS.line}`, borderRadius: 10, padding: "9px 18px", fontSize: 13.5, fontWeight: 600, color: COLORS.ink, cursor: "pointer" }}
        >
          Book another appointment
        </button>
      </div>
    </div>
  );
}
