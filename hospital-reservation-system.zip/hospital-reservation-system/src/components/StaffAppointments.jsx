import { useState } from "react";
import { Search, CheckCircle2, XCircle, Trash2 } from "lucide-react";
import { COLORS } from "../data/seed.js";
import StatusPill from "./StatusPill.jsx";

export default function StaffAppointments({ appointments, setAppointments, doctors }) {
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const filtered = appointments.filter((a) => {
    const matchesQuery = a.patientName.toLowerCase().includes(query.toLowerCase()) || a.code.toLowerCase().includes(query.toLowerCase());
    const matchesStatus = statusFilter === "All" || a.status === statusFilter;
    return matchesQuery && matchesStatus;
  });

  const updateStatus = (id, status) => {
    setAppointments((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
  };
  const removeAppt = (id) => setAppointments((prev) => prev.filter((a) => a.id !== id));

  return (
    <div>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 18, alignItems: "center" }}>
        <div style={{ position: "relative", flex: "1 1 220px" }}>
          <Search size={15} style={{ position: "absolute", left: 12, top: 11, color: COLORS.inkSoft }} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search patient or code"
            style={{ width: "100%", padding: "9px 12px 9px 34px", borderRadius: 10, border: `1px solid ${COLORS.line}`, fontSize: 13.5, outline: "none", fontFamily: "inherit" }}
          />
        </div>
        {["All", "Pending", "Confirmed", "Cancelled"].map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            style={{
              padding: "8px 13px", borderRadius: 999, fontSize: 13, fontWeight: 600, cursor: "pointer",
              border: `1px solid ${statusFilter === s ? COLORS.primary : COLORS.line}`,
              background: statusFilter === s ? COLORS.primary : "transparent",
              color: statusFilter === s ? "#fff" : COLORS.ink,
            }}
          >
            {s}
          </button>
        ))}
      </div>

      <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.line}`, borderRadius: 16, overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5 }}>
            <thead>
              <tr style={{ background: COLORS.bg, textAlign: "left" }}>
                {["Code", "Patient", "Doctor", "Date", "Time", "Status", ""].map((h) => (
                  <th key={h} style={{ padding: "10px 16px", fontSize: 11.5, textTransform: "uppercase", letterSpacing: 0.5, color: COLORS.inkSoft, fontWeight: 700 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((a) => {
                const doc = doctors.find((d) => d.id === a.doctorId);
                return (
                  <tr key={a.id} style={{ borderTop: `1px solid ${COLORS.bg}` }}>
                    <td className="hr-mono" style={{ padding: "12px 16px", color: COLORS.primaryDark, fontWeight: 600 }}>{a.code}</td>
                    <td style={{ padding: "12px 16px", fontWeight: 600, color: COLORS.ink }}>{a.patientName}</td>
                    <td style={{ padding: "12px 16px", color: COLORS.inkSoft }}>{doc ? doc.name : "—"}</td>
                    <td style={{ padding: "12px 16px", color: COLORS.inkSoft }}>{a.date || "—"}</td>
                    <td className="hr-mono" style={{ padding: "12px 16px", color: COLORS.inkSoft }}>{a.time}</td>
                    <td style={{ padding: "12px 16px" }}><StatusPill status={a.status} /></td>
                    <td style={{ padding: "12px 16px" }}>
                      <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                        {a.status !== "Confirmed" && (
                          <button onClick={() => updateStatus(a.id, "Confirmed")} title="Confirm" style={{ background: "none", border: "none", cursor: "pointer", color: COLORS.primary }}>
                            <CheckCircle2 size={17} />
                          </button>
                        )}
                        {a.status !== "Cancelled" && (
                          <button onClick={() => updateStatus(a.id, "Cancelled")} title="Cancel" style={{ background: "none", border: "none", cursor: "pointer", color: COLORS.amber }}>
                            <XCircle size={17} />
                          </button>
                        )}
                        <button onClick={() => removeAppt(a.id)} title="Delete" style={{ background: "none", border: "none", cursor: "pointer", color: COLORS.accent }}>
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr><td colSpan={7} style={{ padding: 24, textAlign: "center", color: COLORS.inkSoft }}>No reservations match your filters.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
